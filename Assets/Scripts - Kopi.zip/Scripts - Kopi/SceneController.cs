﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public static class Globals
{
    public static int score = 0;
    public static int errors = 0;
    public static int errorsA = 0;
    public static int errorsB = 0;
    public static int[] clickSequence = new int[5000];
    public static int[] currentCycleSequence = new int[5000];
    public static int iterations = 0;
    public static int currentCycleIterations = 0;
    public static float timer = 0;
    public static bool writeToFile = false;
    public static bool clickOnStart = false;
    public static bool gameStarted = false;
    public static bool restartTimer = false;
    public static int sceneNumber = 3;
    public static bool nextFlag = false;
    public static int gameLevel = 3;
    public static bool pauseGame = false;
    public static bool levelFour = false;
    public static bool levelFive = false;
    public static bool levelSix = false;
    public static bool levelSeven = false;
    public static bool moveFlag = false;

    // Flags for identifying when each level is completed (this happens when each red circle is found)
    public static bool level3Complete = false;
    public static bool level4Complete = false;
    public static bool level5Complete = false;
    public static bool level6Complete = false;


    // variables for saving each levels results into a string. They are saved as a whole at the end
    public static string resultsLevel3 = "";
    public static string resultsLevel4 = "";
    public static string resultsLevel5 = "";
    public static string resultsLevel6 = "";

    public static string playerName = "";
    public static string finalTime = "";

    public static int clicks_0 = 0;
    public static int clicks_1 = 0;
    public static int clicks_2 = 0;
    public static int clicks_3 = 0;
    public static int clicks_4 = 0;
}

public class SceneController : MonoBehaviour
{
    public GameObject MainSquare;
    public GameObject SecondSquare;
    public GameObject ThirdSquare;
    public GameObject ForthSquare;
    public GameObject PlayingArea;
    public GameObject DropArea;
    public GameObject doneMessage;
    public GameObject nextSceneButton;
    //[SerializeField] private GameObject Square_Yellow;
    bool[] flagsArray = {false, false, false, false, false, false, false, false, false, false, false, false};
    private int startSquare = 0;

    List<GameObject> squares = new List<GameObject>();
    List<GameObject> squares4 = new List<GameObject>();
    List<GameObject> squares5 = new List<GameObject>();
    List<GameObject> squares6 = new List<GameObject>();


    // Start is called before the first frame update
    void Start()
    {
        /* These elements are active for debuggin purposes only */
        /* Unncomment for final version */
        gameLevelText.SetActive(false);
        errorLabel.SetActive(false);
        scoreLabel.SetActive(false);
        TimeLabel.SetActive(false);
        /*******************************************************/

        doneMessage.SetActive(false);
        nextSceneButton.SetActive(false);
        if (Globals.gameStarted){
            BeginTest(Globals.gameLevel);
        }
    }

    public void BeginTest(int level)
    {

        int yellowRandom = Random.Range(0,level);   // Defines a random position for the first Yellow Square
        int posX = Random.Range(-280,280);      // First random position for the first Square (x axis)
        int posY = Random.Range(-170,170);      // First random position for the first Square (y axis)

        // Cykel for creating 5 Squares when clicking on Start button
        for (int i = 0; i < level; i++){          
            GameObject playerSquare = Instantiate(MainSquare, new Vector3(posX,posY,0), Quaternion.identity);
            playerSquare.transform.SetParent(PlayingArea.transform, false);
            playerSquare.transform.Find("Square_Yellow").gameObject.SetActive(false);   // By default all Yellow Squares are not active
            squares.Add(playerSquare);   // add each Square to the list for future use/referance

            // Set the random selected Yellow Square as active (only when game starts)
            if (i == 0){
                playerSquare.transform.Find("Square_Yellow").gameObject.SetActive(true);
                flagsArray[i] = true;
                startSquare = i;     
            }
            posX = Random.Range(-280,280);
            posY = Random.Range(-170,170);
        }
     
    }

    public void BeginTest4(int level)
    {

        int yellowRandom = Random.Range(0,level);   // Defines a random position for the first Yellow Square
        int posX = Random.Range(-280,280);      // First random position for the first Square (x axis)
        int posY = Random.Range(-170,170);      // First random position for the first Square (y axis)

        // Cykel for creating 4 Squares on Level 4
        for (int i = 0; i < level; i++){          
            GameObject playerSquare = Instantiate(SecondSquare, new Vector3(posX,posY,0), Quaternion.identity);
            playerSquare.transform.SetParent(PlayingArea.transform, false);
            playerSquare.transform.Find("Square_Yellow").gameObject.SetActive(false);   // By default all Yellow Squares are not active
            squares4.Add(playerSquare);   // add each Square to the list for future use/referance

            // Set the random selected Yellow Square as active (only when game starts)
            if (i == 0){
                playerSquare.transform.Find("Square_Yellow").gameObject.SetActive(true);
                flagsArray[i] = true;
                startSquare = i;     
            }
            posX = Random.Range(-280,280);
            posY = Random.Range(-170,170);
        }
     
    }

    public void BeginTest5(int level)
    {

        int yellowRandom = Random.Range(0,level);   // Defines a random position for the first Yellow Square
        int posX = Random.Range(-280,280);      // First random position for the first Square (x axis)
        int posY = Random.Range(-170,170);      // First random position for the first Square (y axis)

        // Cykel for creating 5 Squares on Level 5
        for (int i = 0; i < level; i++){          
            GameObject playerSquare = Instantiate(ThirdSquare, new Vector3(posX,posY,0), Quaternion.identity);
            playerSquare.transform.SetParent(PlayingArea.transform, false);
            playerSquare.transform.Find("Square_Yellow").gameObject.SetActive(false);   // By default all Yellow Squares are not active
            squares5.Add(playerSquare);   // add each Square to the list for future use/referance

            // Set the random selected Yellow Square as active (only when game starts)
            if (i == 0){
                playerSquare.transform.Find("Square_Yellow").gameObject.SetActive(true);
                flagsArray[i] = true;
                startSquare = i;     
            }
            posX = Random.Range(-280,280);
            posY = Random.Range(-170,170);
        }
     
    }

    public void BeginTest6(int level)
    {

        int yellowRandom = Random.Range(0,level);   // Defines a random position for the first Yellow Square
        int posX = Random.Range(-280,280);      // First random position for the first Square (x axis)
        int posY = Random.Range(-170,170);      // First random position for the first Square (y axis)

        // Cykel for creating 5 Squares on Level 5
        for (int i = 0; i < level; i++){          
            GameObject playerSquare = Instantiate(ForthSquare, new Vector3(posX,posY,0), Quaternion.identity);
            playerSquare.transform.SetParent(PlayingArea.transform, false);
            playerSquare.transform.Find("Square_Yellow").gameObject.SetActive(false);   // By default all Yellow Squares are not active
            squares6.Add(playerSquare);   // add each Square to the list for future use/referance

            // Set the random selected Yellow Square as active (only when game starts)
            if (i == 0){
                playerSquare.transform.Find("Square_Yellow").gameObject.SetActive(true);
                flagsArray[i] = true;
                startSquare = i;     
            }
            posX = Random.Range(-280,280);
            posY = Random.Range(-170,170);
        }
     
    }

    public void ResetVariables()
    {
        Globals.score = 0;
        Globals.errors = 0;
        Globals.errorsA = 0;
        Globals.errorsB = 0;
        Globals.iterations = 0;
        Globals.currentCycleIterations = 0;
        startSquare = 0;
        for(int i = 0; i < 11; i++){
            flagsArray[i] = false;
        }
    }

    [SerializeField] private GameObject gameLevelText;
    [SerializeField] private GameObject errorLabel;
    [SerializeField] private GameObject TimeLabel;
    [SerializeField] private GameObject scoreLabel;

    // Update is called once per frame
    void Update()
    {
        // Automatically move Red Cicle
        /*if(Globals.moveFlag && MainSquare.transform.Find("Square_Yellow")){
            float shipSpeed = 7.0f;
            float totalSpeed = shipSpeed * Time.deltaTime;
            MainSquare.transform.Find("Square_Yellow").Translate(Vector3.down * totalSpeed);
            Globals.moveFlag = false;
        }*/
        if(Globals.clickOnStart && !Globals.gameStarted)
        {
            BeginTest(3);
            Globals.gameStarted = true;
        }

        gameLevelText.GetComponent<UnityEngine.UI.Text>().text = "Game Level: " + Globals.gameLevel;
        errorLabel.GetComponent<UnityEngine.UI.Text>().text = "Fejl: " + Globals.errors;
        scoreLabel.GetComponent<UnityEngine.UI.Text>().text = "Score: " + Globals.score;
        TimeLabel.GetComponent<UnityEngine.UI.Text>().text = "Tid: " + System.Environment.NewLine + Globals.timer.ToString("0.0");
        //.ToString("0.0");


        //************************ BEGIN - PLACE NEW YELLOW SQUARE FOR THE DIFFERENT LEVELS ******************************************
        // Find the square for the new Yellow Square - Level 3
        if(Globals.gameLevel == 3 && startSquare < 2){
            if(flagsArray[startSquare] && squares[startSquare].transform.childCount == 1){
                startSquare++;
                flagsArray[startSquare] = true;
                squares[startSquare].transform.Find("Square_Yellow").gameObject.SetActive(true);
            }
            else{
                
            }
        }
        else
        {
            // Find the square for the new Yellow Square - Level 4
            if(Globals.gameLevel == 4 && startSquare < 3 && Globals.levelFour){
                if(flagsArray[startSquare] && squares4[startSquare].transform.childCount == 1){
                    startSquare++;
                    flagsArray[startSquare] = true;
                    squares4[startSquare].transform.Find("Square_Yellow").gameObject.SetActive(true);
                }
            }
            else{
                if(Globals.gameLevel == 5 && startSquare < 4 && Globals.levelFive){
                    if(flagsArray[startSquare] && squares5[startSquare].transform.childCount == 1){
                        startSquare++;
                        flagsArray[startSquare] = true;
                        squares5[startSquare].transform.Find("Square_Yellow").gameObject.SetActive(true);
                    }
                }
                else{
                    if(Globals.gameLevel == 6 && startSquare < 5 && Globals.levelSix){
                        if(flagsArray[startSquare] && squares6[startSquare].transform.childCount == 1){
                            startSquare++;
                            flagsArray[startSquare] = true;
                            squares6[startSquare].transform.Find("Square_Yellow").gameObject.SetActive(true);
                        }
                    }    
                }    
            }
        }

        //************************ END - PLACE NEW YELLOW SQUARE FOR THE DIFFERENT LEVELS ******************************************

        
        // Show messages and NEXT button each time a level is completed
        if((Globals.score == 3 && Globals.gameLevel == 3) || (Globals.score == 4 && Globals.gameLevel == 4) || (Globals.score == 5 && Globals.gameLevel == 5) || (Globals.score == 6 && Globals.gameLevel == 6))
        {
            // Show "DONE!" messeage when a level is completed
            //GameObject GameOver = Instantiate(doneMessage, new Vector3(0,0,0), Quaternion.identity);
            doneMessage.gameObject.SetActive(true);
            //GameOver.transform.SetParent(PlayingArea.transform, false);

            nextSceneButton.SetActive(true);
            //Globals.writeToFile = true;
            Globals.nextFlag = true;
            Globals.level3Complete = true;
            Globals.gameLevel++;
            Globals.pauseGame = true;
            
        }

        // What to do if the level 3 is completed
        if(Globals.gameLevel == 4 && !Globals.levelFour && Globals.sceneNumber == 4){
            for (int i = 0; i < 3; i++){
                squares[i].gameObject.SetActive(false);
                DropArea.transform.GetChild(i).gameObject.SetActive(false);
                //DropArea.transform.Find("Square_Yellow").gameObject.SetActive(false);
            }
            // Copy results from Level 3 to string line
            Globals.resultsLevel3 = Globals.errors + "," + Globals.errorsA + "," + Globals.errorsB + "," + Globals.finalTime + ",";
            doneMessage.gameObject.SetActive(false);
            ResetVariables();
            BeginTest4(Globals.gameLevel);
            
            Globals.pauseGame = false;           
            Globals.levelFour = true;
        }

        // What to do if the level 4 is completed
        if(Globals.gameLevel == 5 && !Globals.levelFive && Globals.sceneNumber == 5){
            for (int i = 0; i < 4; i++){
                squares4[i].gameObject.SetActive(false);
                DropArea.transform.GetChild(i+3).gameObject.SetActive(false);
                //DropArea.transform.Find("Square_Yellow").gameObject.SetActive(false);
            }
            // Copy results from Level 4 to string line
            Globals.resultsLevel4 = Globals.errors + "," + Globals.errorsA + "," + Globals.errorsB + "," + Globals.finalTime + ",";
            doneMessage.gameObject.SetActive(false);
            ResetVariables();
            BeginTest5(Globals.gameLevel);
            
            Globals.pauseGame = false;           
            Globals.levelFive = true;
        }

        // What to do if the level 5 is completed
        if(Globals.gameLevel == 6 && !Globals.levelSix && Globals.sceneNumber == 6){
            for (int i = 0; i < 5; i++){
                squares5[i].gameObject.SetActive(false);
                DropArea.transform.GetChild(i+7).gameObject.SetActive(false);
                //DropArea.transform.Find("Square_Yellow").gameObject.SetActive(false);
            }
            // Copy results from Level 5 to string line
            Globals.resultsLevel5 = Globals.errors + "," + Globals.errorsA + "," + Globals.errorsB + "," + Globals.finalTime + ",";
            //Globals.writeToFile = true; // ONLY write at the end of the last level.
            doneMessage.gameObject.SetActive(false);
            ResetVariables();
            BeginTest6(Globals.gameLevel);
            
            Globals.pauseGame = false;           
            Globals.levelSix = true;
        }

        // What to do if the level 6 is completed
        if(Globals.gameLevel == 7 && !Globals.levelSeven && Globals.sceneNumber == 7){
            for (int i = 0; i < 6; i++){
                squares6[i].gameObject.SetActive(false);
                DropArea.transform.GetChild(i+12).gameObject.SetActive(false);
                //DropArea.transform.Find("Square_Yellow").gameObject.SetActive(false);
            }
            // Copy results from Level 6 to string line
            Globals.resultsLevel6 = Globals.errors + "," + Globals.errorsA + "," + Globals.errorsB + "," + Globals.finalTime; //No comma at the last level
            Globals.writeToFile = true; // ONLY write at the end of the last level.
            doneMessage.gameObject.SetActive(false);
            ResetVariables();
            //BeginTest6(Globals.gameLevel);
            
            //Globals.pauseGame = false; // ONLY reset time if the game continues... if not. STOP           
            Globals.levelSeven = true;
        }

    }
}
